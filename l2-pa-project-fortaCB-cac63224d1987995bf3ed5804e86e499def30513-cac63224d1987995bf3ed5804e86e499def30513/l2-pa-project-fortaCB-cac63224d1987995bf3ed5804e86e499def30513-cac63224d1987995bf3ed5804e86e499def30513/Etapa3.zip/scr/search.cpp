#pragma clang diagnostic push
#pragma ide diagnostic ignored "modernize-deprecated-headers"
// search.cpp
// Created by adrian on 20.04.2020.

#include "def.h"
#include <vector>
#include <sys/time.h>

using namespace std;

const int kInf = 30000;

long getTime() {
    struct timeval time{};
    gettimeofday(&time, nullptr);
    long t = time.tv_sec * 1000 + time.tv_usec / 1000;
    return t;
}

bool isRepetition(Board *pos) {
    for (int i = pos->ply - pos->fiftyMoves - 1; i < pos->ply - 1; ++i) {
        if(pos->hashKey == pos->history[i].hashKey)
            return true;
    }
    return false;
}

static void checkUp() {
    // .. check if time up, or interrupt from GUI
}

static void clearForSearch(SearchInfo *info, Board *pos) {
    for (auto & i : pos->searchHistory) {
        for (int & j : i)
            j = 0;
    }
    for (auto & searchKiller : pos->searchKillers) {
        for (int & j : searchKiller)
            j = 0;
    }
    pos->pvTable.clear();
    pos->pvTable = vector<PrincipalVariationEntry>(TABLE_SIZE, PrincipalVariationEntry());
    // TODO ?: nr cum facem sa separam ply vs alpha-beta ply
    // alpha-beta_ply --;

    info->start = getTime();
    info->stopped = false;
    info->nodes = 0;
    info->fh = 0;
    info->fhf = 0;
}

static int quietScene(int alpha, int beta, SearchInfo *info, Board *pos) {
    return 0;
}

static int alphaBeta(int alpha, int beta, int depth, SearchInfo *info, Board *pos, bool DoNull) {
    ASSERT(checkBoard(pos))

    if (depth  == 0) {
        info->nodes++;
        return evalPosition(pos);
    }

    info->nodes++;
    if(threeRep(pos) || pos->fiftyMoves >= 100) {
        return 0;
    }

    vector<Move> allMoves;
    generateAllMoves(pos, allMoves);

    int oldAlpha = alpha;
    int legalMoves = 0;
    Move bestMove = *NOMOVE;
    int score = -kInf;

    for (auto & move : allMoves) {
        if (!makeMove(move, pos))
            continue;

        legalMoves++;
        score = -alphaBeta(-beta, -alpha, depth-1, info, pos, true);
        undoMove(pos);

        if (score > alpha) {
            if (score >= beta) {
                if (legalMoves == 1)
                    info->fhf++;
                info->fh++;
                return beta;
            }
            alpha = score;
            bestMove = move;
        }
    }
    if (legalMoves == 0) {
        int side = pos->side;
        // mate or stalemate
        if (sqAttacked(pos->pList[wK + 6*side][pos->pcsNum[wK + 6*side] - 1], pos->side, pos))
            return -MATE + depth + 1;
        else
            return 0;
    }

    if (alpha != oldAlpha)
        storePvMove(pos, bestMove);

    return alpha;
}

void searchPosition(SearchInfo *info, Board *pos) {
    Move bestMove = *NOMOVE;
    int bestScore;
    int pvMoves;

    clearForSearch(info, pos);

    for (int currentDepth = 1; currentDepth <= info->depth; ++currentDepth) {
        bestScore = alphaBeta(-kInf, kInf, currentDepth, info, pos, true);
        // TODO : out of time?
        pvMoves = getPvLine(currentDepth, pos);
        bestMove = pos->pvArray[0];
        printf("Depth: %d score: %d move: %s nodes: %d time: %ld ordering: %f\n",
                currentDepth, bestScore, prMove(bestMove), info->nodes, getTime() - info->start, (info->fhf / info->fh));
        for (int i = 0; i < pvMoves; ++i)
           cout << prMove(pos->pvArray[i]) << " ";
        cout << endl;
    }
    info->stop = getTime();
}


#pragma clang diagnostic pop