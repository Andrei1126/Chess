// perf.cpp
// Created by adrian on 21.04.2020.

#include "def.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

long long leafNodes;

void perft(int depth, Board *pos) {
    ASSERT(checkBoard(pos));

    if (depth == 0) {
        leafNodes++;
        return;
    }
    std::vector<Move> list;
    generateAllMoves(pos, list);

    for (Move move : list) {
        if (!makeMove(move, pos))
            continue;

        perft(depth-1, pos);
        undoMove(pos);
    }

}

long long perftTest(int depth, Board *pos) {
    ASSERT(checkBoard(pos));

    printBoard(pos);
    cout << "\nStarting Test To Depth: " << depth << endl;
    leafNodes = 0;

    std::vector<Move> list;
    generateAllMoves(pos,list);

    Move move;
    for (int i = 0; i < list.size(); i++) {
        move = list[i];
        if (!makeMove(move, pos))
            continue;
        long newNodes = leafNodes;
        perft(depth-1, pos);
        undoMove(pos);
        long oldNodes = leafNodes - newNodes;
        printf("move %d : %s : %ld\n", i + 1, prMove(move), oldNodes);
    }
    printf("\nTest Complete : %lld nodes visited\n", leafNodes);
    return leafNodes;
}

void parsePerfTable(int depth, Board *b) {
    string line;
    ifstream fin("perf.in");
    ofstream fout("perf.out");
    vector<string> fens = vector<string>(126);
    vector<vector<int>> result = vector<vector<int>>(126, vector<int>(6));
    string s;
    long long d = 0, t = 0;
    for (int k =0 ; k < 126; k++) {
        getline(fin, line);
        stringstream sin(line);
        getline(sin, s, ';');
        fens.push_back(s);
        fout << fens.back() << "    ";
        for (int i = 0; i < 6; i++) {
            getline(sin, s, ';');
            stringstream x(s);
            long n;
            char c;
            x >> c >> c >> n;
            result[k][i] = n;
            parseFen(fens.back(), b);
            long done = 0;
            if (i < depth)
                done = perftTest(i + 1, b);
            if (i == depth - 1) {
                d += done;
                t += n;
            }

            fout << n - done << " ";
        }
        fout << endl;
    }
    printf("\n\nPerf Test completed: %lld/%lld nodes found\n", d, t);
}