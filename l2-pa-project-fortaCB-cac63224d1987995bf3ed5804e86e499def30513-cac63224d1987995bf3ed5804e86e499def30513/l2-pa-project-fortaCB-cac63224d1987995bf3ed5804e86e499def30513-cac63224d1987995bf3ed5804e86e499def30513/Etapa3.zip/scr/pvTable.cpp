// pvTable.cpp
// Created by adrian on 20.04.2020.
#include "def.h"
#include <vector>
using namespace std;

void initPvTable(vector<PrincipalVariationEntry> &pvTable) {
    pvTable.clear();
    pvTable = vector<PrincipalVariationEntry>(TABLE_SIZE, PrincipalVariationEntry());
    cout << TABLE_SIZE * sizeof(PrincipalVariationEntry) << " " << TABLE_SIZE << endl;
}

void storePvMove(Board *pos, Move move) {
    U32 index = pos->hashKey % pos->pvTable.size();

//    printf("%llu %lu %u\n", pos->hashKey, pos->pvTable.size(), index);

    ASSERT(index >= 0 && index <= pos->pvTable.size())
    pos->pvTable[index].move = move;
    pos->pvTable[index].key = pos->hashKey;
}

Move probePvMove(Board *pos) {
    U32 index = pos->hashKey % pos->pvTable.size();
//    printf("%llu %lx %u\n", pos->hashKey, pos->pvTable.size(), index);
    ASSERT(index >= 0 && index <= pos->pvTable.size())

    if( pos->pvTable[index].key == pos->hashKey )
        return pos->pvTable[index].move;

    return *NOMOVE;
}

int getPvLine(int depth, Board *pos) {
    ASSERT(depth < 64);
    Move move = probePvMove(pos);
    int count = 0;

    while (!move.compareTo(NOMOVE) && count < depth) {
        if (moveExists(move, pos)) {
            makeMove(move, pos);
            pos->pvArray[count] = move;
            count++;
        } else {
            break;
        }
        move = probePvMove(pos);
    }

    for(int i = count; i ; i--) {
        undoMove(pos);
    }
    return count;
}
// TODO 8: functie care scoate cea mai buna linie
//int max = GetPvLine(4, board);
//printf("PvLine of %d Moves: ", max);
//for(PvNum = 0; PvNum < max; ++PvNum) {
//Move = board->PvArray[PvNum];
//printf(" %s",PrMove(Move));
//}

