// Created by adrian on 18.04.2020.

#ifndef DEF_H
#define DEF_H
#include <iostream>
#include <string>
#include <vector>
typedef unsigned long long U64;
typedef unsigned int U32;
typedef unsigned short U16;
typedef unsigned char U8;

enum { EMPTY, wP, wN, wB, wR, wQ, wK, bP, bN, bB, bR, bQ, bK  };
enum { A, B, C, D, E, F, G, H, NONE };
enum { RANK_1, RANK_2, RANK_3, RANK_4, RANK_5, RANK_6, RANK_7, RANK_8, RANK_NONE };
enum { WHITE, BLACK, BOTH };
enum { FALSE, TRUE };
enum { WKCA = 1, WQCA = 2, BKCA = 4, BQCA = 8 };
enum {
    A1 = 21, B1, C1, D1, E1, F1, G1, H1,
    A2 = 31, B2, C2, D2, E2, F2, G2, H2,
    A3 = 41, B3, C3, D3, E3, F3, G3, H3,
    A4 = 51, B4, C4, D4, E4, F4, G4, H4,
    A5 = 61, B5, C5, D5, E5, F5, G5, H5,
    A6 = 71, B6, C6, D6, E6, F6, G6, H6,
    A7 = 81, B7, C7, D7, E7, F7, G7, H7,
    A8 = 91, B8, C8, D8, E8, F8, G8, H8, NO_SQ, OFFBOARD
};

//#define DEBUG

// file-rank to square in 120 array
#define FR2SQ(f,r) ( (21 + (f)) + ((r) * 10) )
#define SQ64(sq120) (Sq120ToSq64[(sq120)])
#define SQ120(sq64) (Sq64ToSq120[(sq64)])
#define NOMOVE (new Move(0,0,0,0))
#define TABLE_SIZE 0x1800000
#define MATE 29000

class Move {
public:

    int from{};
    int to{};
    int captured{};
    bool enPas{};
    int promotion{};
    bool pawnStart{};
    bool castle{};
    int score{};

    Move () {
        from = OFFBOARD;
        to =  OFFBOARD;
        captured = EMPTY;
        promotion = EMPTY;
        enPas = false;
        pawnStart = false;
        castle = false;
        score = 0;
    }

    Move(int from, int to, int captured, int promotion) {
        this->from = from;
        this->to = to;
        this->captured = captured;
        this->promotion = promotion;
        enPas = false;
        castle = false;
        pawnStart = false;
        score = 0;
    }

    Move(int from, int to, int captured, int promotion, int score) {
        this->from = from;
        this->to = to;
        this->captured = captured;
        this->promotion = promotion;
        enPas = false;
        castle = false;
        pawnStart = false;
        this->score = score;
    }

    Move(int from, int to, int captured, int promotion, bool castle, bool pawnStart, bool enPas) {
        this->from = from;
        this->to = to;
        this->captured = captured;
        this->promotion = promotion;
        this->castle = castle;
        this->pawnStart = pawnStart;
        this->enPas = enPas;
        score = 0;
    }

    Move(int from, int to, int captured, int promotion, bool castle, bool pawnStart, bool enPas, int score) {
        this->from = from;
        this->to = to;
        this->captured = captured;
        this->promotion = promotion;
        this->castle = castle;
        this->pawnStart = pawnStart;
        this->enPas = enPas;
        this->score = score;
    }

    bool compareTo(Move *move) {
        return this->from == move->from && this->to == move->to
                && this->promotion == move->promotion;
    }
};
class PrincipalVariationEntry {
public:
    U64 key;
    Move move;

    PrincipalVariationEntry(){
        key = 0;
        move = *NOMOVE;
    }

    PrincipalVariationEntry(U64 key, Move move) {
        this->key = key;
        this->move = move;
    }
};

class Undo {
public:
    Move move;
    int castlePerm;
    int enPas;
    int fiftyMoves;
    U64 hashKey;
};

class Board {
public:
    // 100  100  100  100  100  100  100  100  100  100
    // 100  100  100  100  100  100  100  100  100  100
    // 100   63   62   61   60   59   58   57   56  100
    // 100   55   54   53   52   51   50   49   48  100
    // 100   47   46   45   44   43   42   41   40  100
    // 100   39   38   37   36   35   34   33   32  100
    // 100   31   30   29   28   27   26   25   24  100
    // 100   23   22   21   20   19   18   17   16  100
    // 100   15   14   13   12   11   10    9    8  100
    // 100    7    6    5    4    3    2    1    0  100
    // 100  100  100  100  100  100  100  100  100  100
    // 100  100  100  100  100  100  100  100  100  100
    int pieces[120];

    // 0 alb
    // 1 negru
    int side;
    int enPas;

    // incepe de la 0 cand ajunge la 50 -> egalitate
    // se reseteaza la avansarea unui pion sau la captura
    int fiftyMoves;

    // 1 white king side
    // 2 white queen side
    // 4 black king side
    // 8 black queen side
    int castlePerm;

    // numara mutarile (jumatati de mutari)
    int ply;
    int hisply;
    U64 hashKey;

    // pcsNum[i] = nr de piese i
    int pcsNum[13];
    // bigPcs[side] = nr de piese in afara de pion
    int bigPcs[2];
    // major piece = nr de queen, rook, king
    int majPcs[2];
    // minor piece = nr de bishop, knight
    int minPcs[2];
    // valoarea tuturor pieselor adunate
    int material[2];
    // p[i][j] -> pozitia lui piesei i este j
    int pList[13][10];

    Undo history[1024];

    // nebunii cu alpha-beta iterativ
    std::vector<PrincipalVariationEntry> pvTable;
    Move pvArray[64];


    /**
     * 1. PV moves
     * 2. Cap -> Most valuable victims Less valuable attackers
     * 3. Killer moves
     * 4. History score
     */
     /**
      * P -> Q
      * N -> Q
      * B -> Q
      * R -> Q
      *
      * P -> R
      * N -> R
      * B -> R
      *
      * P -> B
      * N -> B
      *
      * P -> N
      */
    // move ordering in alpha-beta
    int searchHistory[13][120];
    int searchKillers[2][64];
};

typedef struct {
    // start-stop time
    long start;
    long stop;

    int depth;

    // daca e o cautare pe baza de depth sau de time
    bool depthSet;
    bool timeSet;

    // daca an primit comanda quit sau stop de lla xboard
    bool quit;
    bool stopped;

    // daca e o cautare care se opreste doar la comanda stop de la xboard
    bool infinite;
    // nu mie clar daca avem nevoie?
    int movesToGo;

    int nodes;

    // fail high
    float fh;
    // fail high first
    float fhf;

} SearchInfo;

extern int Sq120ToSq64[120];
extern int Sq64ToSq120[64];
extern U64 pieceKeys[13][120];
extern U64 sideKey;
extern U64 castleKeys[16];
extern const int KnDir[8];
extern const int RkDir[4];
extern const int BiDir[4];
extern const int KiDir[8];
extern int pieceVal[13];
extern bool isPieceBig[13];
extern bool isPieceMaj[13];
extern bool isPieceMin[13];
extern int pieceCol[13];
extern const int castlePerm[120];
extern bool isKn[13];
extern bool isKi[13];
extern bool isRQ[13];
extern bool isBQ[13];
extern bool isPawn[13];
extern int files[120];
extern int ranks[120];
extern int mirror64[64];
extern const int kInf;
extern std::vector<std::vector<PrincipalVariationEntry>> openingsBook;
extern char pcsChar[];
extern char sideChar[];

extern U64 generateHashKey(Board *pos);
extern void allInit();
extern void updateListsMaterial(Board *pos);
extern void resetBoard(Board *pos);
extern int sqAttacked(int sq, int side, Board *pos);
extern bool makeMove(Move move, Board *pos);
extern void undoMove(Board *pos);
extern bool isRepetition(Board *pos);
extern int parseFen(std::string fen, Board *pos);
extern void generateAllMoves(Board *pos, std::vector<Move> &allMoves);
extern int evalPosition(Board *pos);
extern Move negamax(int depth, Board *pos, Move m);
extern Move alphaBetaNegamax(int alpha, int beta, int depth, Board *pos, Move m);
extern int gameOver(Board *pos);
extern bool threeRep(Board *pos);
extern bool drawMaterial(const Board *pos);
extern void mirrorBoard(Board *pos);
extern Move parseMove(std::string s, Board *b);
extern void initPvTable(std::vector<PrincipalVariationEntry> &pvTable);
extern void storePvMove(Board *pos, Move move);
extern bool moveExists(Move move, Board *pos);
extern int getPvLine(int depth, Board *pos);
extern void searchPosition(SearchInfo *info, Board *pos);
extern long getTime();

// functii de afisare
extern char *prSq(int sq);
extern char *prMove(Move move);
extern void showSqAttackedBySide(int side, Board *pos);
extern void print120();
extern void print64();
extern void printBoard(Board *pos);
extern void printMoveList(std::vector<Move> list);
extern void printMove(Move move);

// validare
extern bool sqOnBoard(int sq);
extern bool sideValid(int side);
extern bool fileRankValid(int fr);
extern bool pieceValidOrEmpty(int pce);
extern bool pieceValid(int pce);
extern bool checkBoard(Board *pos);
extern bool checkBoard2(Board *pos);

// perf
extern long long perftTest(int depth, Board *pos);
extern void parsePerfTable(int depth, Board *b);

// functii de evaluare
extern void testEvalFunction(int depth, Board *b);
extern void testOpeningBook(int i);

#ifndef DEBUG
#define ASSERT(n)
#else
#define ASSERT(n) \
if(!(n)) { \
printf("%s - Failed", #n); \
printf("At %s ",__TIME__); \
printf("In File %s ",__FILE__); \
printf("At Line %d\n",__LINE__); \
exit(1);}
#endif

#ifndef DEBUG
#define ASSERT2(n, move, b)
#else
#define ASSERT2(n, move, b) \
if(!(n)) { \
printf("%s, - Failed\n", #n); \
printMove(move); \
printBoard(b); \
printf("\nAt %s ",__TIME__); \
printf("In File %s ",__FILE__); \
printf("At Line %d\n",__LINE__); \
exit(1);}
#endif

#define START_FEN  "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
#define FEN1 "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1"
#define FEN2 "rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq c6 0 2"
#define FEN3 "rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2"
#define FEN4 "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"
#define PAWNMOVESW "rnbqkb1r/pp1p1pPp/8/2p1pP2/1P1P4/3P3P/P1P1P3/RNBQKBNR w KQkq e6 0 1"
#define PAWNMOVESB "rnbqkbnr/p1p1p3/3p3p/1p1p4/2P1Pp2/8/PP1P1PpP/RNBQKB1R b KQkq e3 0 1"
#define KNIGHTSKINGS "5k2/1n6/4n3/6N1/8/3N4/8/5K2 w - - 0 1"
#define ROOKS "6k1/8/5r2/8/1nR5/5N2/8/6K1 w - - 0 1"
#define QUEENS "6k1/8/4nq2/8/1nQ5/5N2/1N6/6K1 w - - 0 1 "
#define BISHOPS "6k1/1b6/4n3/8/1n4B1/1B3N2/1N6/2b3K1 w - - 0 1 "
#define CASTLE1 "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1"
#define CASTLE2 "3rk2r/8/8/8/8/8/6p1/R3K2R w KQk - 0 1"
#define PERFTFEN "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"

#endif //DEF_H