// perf.cpp
// Created by adrian on 22.04.2020.

#include "def.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

void testEvalFunction(int depth, Board *b) {
    string line;
    ifstream fin("perf.in");
    ofstream fout("testEvalFunction.out");
    vector<string> fens = vector<string>(126);
    vector<vector<int>> result = vector<vector<int>>(126, vector<int>(6));
    string s;
    long long d = 0;
    for (int k = 0; k < 126; k++) {
        getline(fin, line);
        stringstream sin(line);
        getline(sin, s, ';');
        fens.push_back(s);
        fout << fens.back() << "    ";
        parseFen(fens.back(), b);
        Move m;
        m =  alphaBetaNegamax(-1e9,1e9, depth, b, *NOMOVE);
        int alpha = m.score;
        mirrorBoard(b);
        m =  alphaBetaNegamax(-1e9,1e9, depth, b, *NOMOVE);
        int beta = m.score;
        fout << depth << ": " << alpha << "  " << beta << endl;
        if (alpha == beta)
            d++;
        else
            cout<<"Wrong at: "<<k+1<<endl;
        cout << k << endl;
    }
    printf("\n\nEvaluation function Test completed: %lld/126 correct evaluation\n\n", d);
}

void testOpeningBook(int i) {
    cout << "Testing openingsBook:\n";
    int k = 0;
    for (const auto& line: openingsBook) {k++;
        Board *board = new Board;
        parseFen(START_FEN, board);
        int j = 0;
        for (auto pv: line) {j++;
            if (board->hashKey != pv.key) {
                cout << "Fail at line " << k << " move " << j << endl;
                cout << board->hashKey << " vs " << pv.key << endl;
                return;
            }
            makeMove(pv.move, board);
        }
    }
    cout << "Test completed: Success\n";
}


